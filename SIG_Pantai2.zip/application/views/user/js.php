<script src="<?= base_url('public/assets-user/js/jquery.min.js') ?>"></script>
<script src="<?= base_url('public/assets-user/js/browser.min.js') ?>"></script>
<script src="<?= base_url('public/assets-user/js/breakpoints.min.js') ?>"></script>
<script src="<?= base_url('public/assets-user/js/util.js') ?>"></script>
<script src="<?= base_url('public/assets-user/js/main.js') ?>"></script>

<script src="https://unpkg.com/leaflet@1.5.0/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-responsive-popup@0.6.4/leaflet.responsive.popup.js"></script>

<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="
sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin="">
</script>

<script src="<?= base_url('public/leaflet/panel/src/leaflet-panel-layers.js') ?>"></script>
<script src="<?= base_url('public/leaflet/marker/leaflet_awesome_number_markers.js') ?>"></script>
<script src="<?= base_url('public/leaflet/leaflet.ajax.js') ?>"></script>