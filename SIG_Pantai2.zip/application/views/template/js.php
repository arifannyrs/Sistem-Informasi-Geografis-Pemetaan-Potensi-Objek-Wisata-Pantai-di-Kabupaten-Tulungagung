<script src="<?= base_url('public/assets/plugins/jquery/jquery.min.js') ?>"></script>
<script src="<?= base_url('public/assets/plugins/bootstrap/js/tether.min.js') ?>"></script>
<script src="<?= base_url('public/assets/plugins/bootstrap/js/bootstrap.min.js') ?>"></script>
<script src="<?= base_url('public/js/jquery.slimscroll.js') ?>"></script>
<script src="<?= base_url('public/js/waves.js') ?>"></script>
<script src="<?= base_url('public/js/sidebarmenu.js') ?>"></script>
<script src="<?= base_url('public/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js') ?>"></script>
<script src="<?= base_url('public/js/custom.min.js') ?>"></script>

<script src="<?= base_url('public/assets/plugins/d3/d3.min.js') ?>"></script>
<script src="<?= base_url('public/assets/plugins/c3-master/c3.min.js') ?>"></script>

