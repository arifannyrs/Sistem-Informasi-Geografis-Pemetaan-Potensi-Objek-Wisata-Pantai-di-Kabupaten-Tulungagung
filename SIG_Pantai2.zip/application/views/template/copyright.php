<footer class="footer">
    © <?= date('Y') . ' -SIG PANTAI' ?>
</footer>